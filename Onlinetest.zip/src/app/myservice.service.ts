import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updateemployee: Userdata;
  constructor(private httpService: HttpClient) { }
  public getUsers() {
    console.log("ins service get users");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Userdata>("http://localhost:8299/user/GetAllUsers");
  }

  public addUser(addemp: Userdata) {
    console.log("ins service add");
    console.log(addemp);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8299/user/addUser", addemp,  { headers, responseType: 'text'});
  }
  
  public update(updateemployee: Userdata) {
    this.updateemployee = updateemployee;
  }
  public updateMethod() {
    return this.updateemployee;
  }
  public onUpdate(updatemp: Userdata) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put("http://localhost:8299/user/UpdateUser", updatemp,  { headers, responseType: 'text'});
  }
  delete(id: number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:8299/user/DeleteUser/" + id,  { headers, responseType: 'text'});
  }
  login(u:Userdata){
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put("http://localhost:8299/user/Loginuser", u,  { headers, responseType: 'text'});
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}
export class Userdata{
  userId:number;
  userName:string;
  userType:string;
  userPassword:string;
  userPhoneno:number;
  userEmail:string;
}